import java.util.HashMap;
import java.util.Map;

public class Buyer {
    private Map<Product, Integer> cart;
    private double totalPrice;

    public Buyer() {
        cart = new HashMap<>();
        totalPrice = 0.0;
    }

    public void addProductToCart(Product product) {
        cart.put(product, cart.getOrDefault(product, 0) + 1);
        updateTotalPrice();
    }

    public void removeProductFromCart(Product product) {
        if (cart.containsKey(product)) {
            cart.remove(product);
            updateTotalPrice();
        }
    }

    public void increaseProductQuantity(Product product) {
        cart.put(product, cart.getOrDefault(product, 0) + 1);
        updateTotalPrice();
    }

    public void decreaseProductQuantity(Product product) {
        if (cart.containsKey(product)) {
            int quantity = cart.get(product);
            if (quantity > 1) {
                cart.put(product, quantity - 1);
            } else {
                cart.remove(product);
            }
            updateTotalPrice();
        }
    }

    private void updateTotalPrice() {
        totalPrice = 0.0;
        for (Map.Entry<Product, Integer> entry : cart.entrySet()) {
            totalPrice += entry.getKey().getPrice() * entry.getValue();
        }
    }

    public Map<Product, Integer> getCart() {
        return cart;
    }

    public double getTotalPrice() {
        return totalPrice;
    }
}
