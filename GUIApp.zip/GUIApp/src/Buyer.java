
import java.util.HashMap;
import java.util.Map;

class Buyer {
    private Map<Product, Integer> cart;

    public Buyer() {
        cart = new HashMap<>();
    }

    public void addProductToCart(Product product) {
        cart.put(product, cart.getOrDefault(product, 0) + 1);
    }

    public String getCartContents() {
        StringBuilder contents = new StringBuilder();
        contents.append(String.format("%-20s %-10s %-10s %-10s\n", "Product", "Quantity", "ID", "Price"));
        double totalPrice = 0.0;
        for (Map.Entry<Product, Integer> entry : cart.entrySet()) {
            Product product = entry.getKey();
            int quantity = entry.getValue();
            double price = product.getPrice() * quantity;
            contents.append(String.format("%-20s %-10d %-10d $%-10.2f\n", product.getName(), quantity, product.getId(), price));
            totalPrice += price;
        }
        contents.append("\nTotal Price: $" + totalPrice);
        return contents.toString();
    }
}