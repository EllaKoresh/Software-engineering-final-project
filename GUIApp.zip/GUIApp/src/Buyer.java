
import java.util.HashMap;
import java.util.Map;

class Buyer {
    private Map<Product, Integer> cart;

    public Buyer() {
        cart = new HashMap<>();
    }

    public void addProductToCart(Product product) {
        cart.put(product, cart.getOrDefault(product, 0) + 1);
    }

    public void removeProductFromCart(Product product) {
        if (cart.containsKey(product)) {
            cart.remove(product);
        }
    }

    public void increaseProductQuantity(Product product) {
        cart.put(product, cart.getOrDefault(product, 0) + 1);
    }

    public void decreaseProductQuantity(Product product) {
        if (cart.containsKey(product) && cart.get(product) > 1) {
            cart.put(product, cart.get(product) - 1);
        }
    }

    public Map<Product, Integer> getCart() {
        return cart;
    }

    public double getTotalPrice() {
        double totalPrice = 0.0;
        for (Map.Entry<Product, Integer> entry : cart.entrySet()) {
            totalPrice += entry.getKey().getPrice() * entry.getValue();
        }
        return totalPrice;
    }
}
