import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class CartTableModel extends AbstractTableModel {
    private final String[] columnNames = { "Product", "Quantity", "ID", "Price", "del", "↑", "↓" };
    private Buyer buyer;

    public CartTableModel(Buyer buyer) {
        this.buyer = buyer;
    }

    @Override
    public int getRowCount() {
        return buyer.getCart().size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        List<Product> products = new ArrayList<>(buyer.getCart().keySet());
        Product product = products.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return product.getName();
            case 1:
                return buyer.getCart().get(product);
            case 2:
                return product.getId();
            case 3:
                return "$" + String.format("%.2f", product.getPrice() * buyer.getCart().get(product));
            case 4:
                return "del";
            case 5:
                return "↑";
            case 6:
                return "↓";
            default:
                return null;
        }
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return columnIndex == 4 || columnIndex == 5 || columnIndex == 6;
    }

    @Override
    public void fireTableDataChanged() {
        super.fireTableDataChanged();
    }
}
