public class BasicCalculator {

    public double evaluate(String expression) throws Exception {
        String[] tokens = expression.split(" ");
        if (tokens.length != 3) {
            throw new Exception("Invalid expression");
        }

        double operand1 = Double.parseDouble(tokens[0]);
        char operator = tokens[1].charAt(0);
        double operand2 = Double.parseDouble(tokens[2]);

        switch (operator) {
            case '+':
                return operand1 + operand2;
            case '-':
                return operand1 - operand2;
            case '*':
                return operand1 * operand2;
            case '/':
                if (operand2 == 0) {
                    throw new ArithmeticException("Division by zero");
                }
                return operand1 / operand2;
            default:
                throw new Exception("Invalid operator");
        }
    }
}
