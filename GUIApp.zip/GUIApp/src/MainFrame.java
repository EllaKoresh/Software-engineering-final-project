import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MainFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JPanel mainPanel;
    private CheckOutPanel checkOutPanel; // Updated to CheckOutPanel
    private Buyer buyer;
    private Shop shop;
    private JButton[] productSlots;
    private int currentPage;
    private JTable cartTable;
    private CartTableModel cartTableModel;
    private JLabel totalPriceLabel; // Updated to JLabel

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public MainFrame() {
        buyer = new Buyer();
        shop = new Shop();
        currentPage = 0;

        // Add some products to the shop
        shop.addProduct(new Product("Tomato", 1.50, 101));
        shop.addProduct(new Product("Apple", 1.20, 102));
        shop.addProduct(new Product("Banana", 0.80, 103));
        shop.addProduct(new Product("Orange", 1.00, 104));
        shop.addProduct(new Product("Milk", 1.50, 105));
        shop.addProduct(new Product("Bread", 2.00, 106));
        shop.addProduct(new Product("Cheese", 3.50, 107));
        shop.addProduct(new Product("Yogurt", 0.90, 108));
        shop.addProduct(new Product("Chicken", 5.00, 109));
        shop.addProduct(new Product("Beef", 7.00, 110));
        shop.addProduct(new Product("Fish", 6.50, 111));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1170, 626);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new CardLayout());

        // Main panel setup
        mainPanel = new JPanel();
        mainPanel.setLayout(null);
        contentPane.add(mainPanel, "MainPanel");

        // Initialize product slots
        productSlots = new JButton[10];
        for (int i = 0; i < 10; i++) {
            productSlots[i] = new JButton();
            productSlots[i].setBackground(SystemColor.inactiveCaption);
            productSlots[i].setForeground(SystemColor.windowText);
            productSlots[i].setFont(new Font("Sitka Text", Font.BOLD, 14));
            productSlots[i].setBounds(25 + (i % 2) * 188, 128 + (i / 2) * 69, 158, 43);
            mainPanel.add(productSlots[i]);

            productSlots[i].addActionListener(e -> {
                JButton source = (JButton) e.getSource();
                String productName = source.getText();
                for (Product product : shop.getProducts()) {
                    if (product.getName().equals(productName)) {
                        buyer.addProductToCart(product);
                        cartTableModel.fireTableDataChanged();
                        updateTotalPriceLabel(); // Update the total price label
                        break;
                    }
                }
            });
        }

        // Initialize cart table
        cartTableModel = new CartTableModel(buyer);
        cartTable = new JTable(cartTableModel);
        cartTable.setFillsViewportHeight(true);
        cartTable.getColumn("del").setCellRenderer(new ButtonRenderer());
        cartTable.getColumn("del").setCellEditor(new ButtonEditor(buyer, cartTable, cartTableModel));
        cartTable.getColumn("↑").setCellRenderer(new ButtonRenderer());
        cartTable.getColumn("↑").setCellEditor(new ButtonEditor(buyer, cartTable, cartTableModel));
        cartTable.getColumn("↓").setCellRenderer(new ButtonRenderer());
        cartTable.getColumn("↓").setCellEditor(new ButtonEditor(buyer, cartTable, cartTableModel));

        JScrollPane scrollPane = new JScrollPane(cartTable);
        scrollPane.setBounds(646, 69, 412, 193);
        mainPanel.add(scrollPane);

        JLabel cartLabel = new JLabel("Cart ");
        cartLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        cartLabel.setForeground(Color.BLACK);
        cartLabel.setBounds(646, 11, 111, 30);
        mainPanel.add(cartLabel);

        // Previous and Next buttons for product slots
        JButton btnPrevious = new JButton("<");
        btnPrevious.setBounds(25, 500, 50, 30);
        mainPanel.add(btnPrevious);
        btnPrevious.addActionListener(e -> {
            if (currentPage > 0) {
                currentPage--;
                updateProductSlots();
            }
        });

        JButton btnNext = new JButton(">");
        btnNext.setBounds(133, 500, 50, 30);
        mainPanel.add(btnNext);
        btnNext.addActionListener(e -> {
            if ((currentPage + 1) * 10 < shop.getProducts().size()) {
                currentPage++;
                updateProductSlots();
            }
        });

        updateProductSlots();

        // Add Calculator Panel
        CalculatorPanel calculatorPanel = new CalculatorPanel();
        calculatorPanel.setBounds(646, 273, 252, 305);
        mainPanel.add(calculatorPanel);

        // Add Checkout Button
        JButton btnCheckOut = new JButton("Checkout");
        btnCheckOut.setBounds(908, 284, 150, 23);
        btnCheckOut.addActionListener(e -> showCheckOutPanel());
        mainPanel.add(btnCheckOut);

        JLabel lblTotalPrice = new JLabel("Total price:");
        lblTotalPrice.setForeground(new Color(0, 255, 127));
        lblTotalPrice.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTotalPrice.setBounds(646, 41, 139, 19);
        mainPanel.add(lblTotalPrice);

        // Initialize totalPriceLabel
        totalPriceLabel = new JLabel("$0.00");
        totalPriceLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        totalPriceLabel.setForeground(new Color(0, 255, 127));
        totalPriceLabel.setBounds(766, 41, 96, 20);
        mainPanel.add(totalPriceLabel);

        // Checkout panel setup
        checkOutPanel = new CheckOutPanel(this); // Ensure CheckOutPanel instance
        contentPane.add(checkOutPanel, "CheckOutPanel");
    }

    private void updateProductSlots() {
        List<Product> products = shop.getProducts();
        int start = currentPage * 10;
        for (int i = 0; i < 10; i++) {
            if (start + i < products.size()) {
                productSlots[i].setText(products.get(start + i).getName());
                productSlots[i].setEnabled(true);
            } else {
                productSlots[i].setText("");
                productSlots[i].setEnabled(false);
            }
        }
    }

    public void updateTotalPriceLabel() {
        double totalPrice = buyer.getTotalPrice();
        totalPriceLabel.setText(String.format("$%.2f", totalPrice));
    }

    private void showCheckOutPanel() {
        CardLayout cl = (CardLayout) contentPane.getLayout();
        cl.show(contentPane, "CheckOutPanel");

        // Update the total price label
        updateTotalPriceLabel();

        // Update the checkout panel
        checkOutPanel.updateTotalPay(buyer.getTotalPrice());
        checkOutPanel.updatePurchaseDetails(buyer.getCart());
        
        setVisible(true);
    }

    public void showMainPanel() {
        CardLayout cl = (CardLayout) contentPane.getLayout();
        cl.show(contentPane, "MainPanel");
        
        setVisible(true);
    }
}
