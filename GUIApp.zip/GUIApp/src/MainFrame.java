import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MainFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextArea textArea_cart;
    private Buyer buyer;
    private Shop shop;
    private JButton[] productSlots;
    private int currentPage;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MainFrame frame = new MainFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public MainFrame() {
        buyer = new Buyer();
        shop = new Shop();
        currentPage = 0;
        
        // Add some products to the shop
        shop.addProduct(new Product("Tomato", 1.50, 101));
        shop.addProduct(new Product("Apple", 1.20, 102));
        shop.addProduct(new Product("Banana", 0.80, 103));
        shop.addProduct(new Product("Orange", 1.00, 104));
        shop.addProduct(new Product("Milk", 1.50, 105));
        shop.addProduct(new Product("Bread", 2.00, 106));
        shop.addProduct(new Product("Cheese", 3.50, 107));
        shop.addProduct(new Product("Yogurt", 0.90, 108));
        shop.addProduct(new Product("Chicken", 5.00, 109));
        shop.addProduct(new Product("Beef", 7.00, 110));
        shop.addProduct(new Product("Fish", 6.50, 111));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1170, 626);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        productSlots = new JButton[10];
        for (int i = 0; i < 10; i++) {
            productSlots[i] = new JButton();
            productSlots[i].setBackground(SystemColor.inactiveCaption);
            productSlots[i].setForeground(SystemColor.windowText);
            productSlots[i].setFont(new Font("Sitka Text", Font.BOLD, 14));
            productSlots[i].setBounds(25 + (i % 2) * 188, 128 + (i / 2) * 69, 158, 43);
            contentPane.add(productSlots[i]);

            productSlots[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JButton source = (JButton) e.getSource();
                    String productName = source.getText();
                    for (Product product : shop.getProducts()) {
                        if (product.getName().equals(productName)) {
                            buyer.addProductToCart(product);
                            textArea_cart.setText(buyer.getCartContents());
                            break;
                        }
                    }
                }
            });
        }

        textArea_cart = new JTextArea();
        textArea_cart.setBounds(651, 119, 412, 328);
        textArea_cart.setEditable(false);  // Make it read-only
        contentPane.add(textArea_cart);

        JLabel CartLabel = new JLabel("Cart ");
        CartLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        CartLabel.setForeground(new Color(0, 0, 0));
        CartLabel.setBounds(650, 78, 111, 30);
        contentPane.add(CartLabel);

        JButton btnPrevious = new JButton("<");
        btnPrevious.setBounds(25, 500, 50, 30);
        contentPane.add(btnPrevious);
        btnPrevious.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (currentPage > 0) {
                    currentPage--;
                    updateProductSlots();
                }
            }
        });

        JButton btnNext = new JButton(">");
        btnNext.setBounds(133, 500, 50, 30);
        contentPane.add(btnNext);
        btnNext.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if ((currentPage + 1) * 10 < shop.getProducts().size()) {
                    currentPage++;
                    updateProductSlots();
                }
            }
        });

        updateProductSlots();
    }

    private void updateProductSlots() {
        List<Product> products = shop.getProducts();
        int start = currentPage * 10;
        for (int i = 0; i < 10; i++) {
            if (start + i < products.size()) {
                productSlots[i].setText(products.get(start + i).getName());
                productSlots[i].setEnabled(true);
            } else {
                productSlots[i].setText("");
                productSlots[i].setEnabled(false);
            }
        }
    }
}