import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CalculatorPanel extends JPanel {
    private JTextField displayField;
    private BasicCalculator calculator;
    private StringBuilder currentInput;

    public CalculatorPanel() {
        calculator = new BasicCalculator();
        currentInput = new StringBuilder();

        setLayout(null);

        displayField = new JTextField();
        displayField.setBounds(10, 10, 233, 40);
        add(displayField);

        int x = 10, y = 60;
        // Create number buttons in a calculator layout
        String[] buttonLabels = {
            "1", "2", "3", 
            "4", "5", "6", 
            "7", "8", "9", 
            "C", "0", "="
        };

        for (int i = 0; i < buttonLabels.length; i++) {
            JButton button = new JButton(buttonLabels[i]);
            button.setBounds(x, y, 50, 50);
            button.addActionListener(new ButtonClickListener(buttonLabels[i]));
            add(button);

            x += 60;
            if (i == 2 || i == 5 || i == 8) { // End of a row
                x = 10;
                y += 60;
            }
        }

        // Layout for operator buttons
        JButton addButton = new JButton("+");
        addButton.setBounds(190, 60, 50, 50);
        addButton.addActionListener(new OperationButtonListener('+'));
        add(addButton);

        JButton subtractButton = new JButton("-");
        subtractButton.setBounds(190, 120, 50, 50);
        subtractButton.addActionListener(new OperationButtonListener('-'));
        add(subtractButton);

        JButton multiplyButton = new JButton("*");
        multiplyButton.setBounds(190, 180, 50, 50);
        multiplyButton.addActionListener(new OperationButtonListener('*'));
        add(multiplyButton);

        JButton divideButton = new JButton("/");
        divideButton.setBounds(190, 240, 50, 50);
        divideButton.addActionListener(new OperationButtonListener('/'));
        add(divideButton);
    }

    private class ButtonClickListener implements ActionListener {
        private String label;

        public ButtonClickListener(String label) {
            this.label = label;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            switch (label) {
                case "C":
                    currentInput.setLength(0);
                    displayField.setText("");
                    break;
                case "=":
                    try {
                        double result = calculator.evaluate(currentInput.toString());
                        displayField.setText(String.valueOf(result));
                        currentInput.setLength(0);
                        currentInput.append(result);
                    } catch (Exception ex) {
                        displayField.setText("Error");
                        currentInput.setLength(0);
                    }
                    break;
                default:
                    currentInput.append(label);
                    displayField.setText(currentInput.toString());
                    break;
            }
        }
    }

    private class OperationButtonListener implements ActionListener {
        private char operation;

        public OperationButtonListener(char operation) {
            this.operation = operation;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            currentInput.append(" ").append(operation).append(" ");
            displayField.setText(currentInput.toString());
        }
    }
}