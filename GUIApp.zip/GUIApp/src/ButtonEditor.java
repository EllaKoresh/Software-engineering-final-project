import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractCellEditor;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import java.util.ArrayList;
import java.util.List;

public class ButtonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
    private JButton button;
    private String label;
    private boolean isPushed;
    private Buyer buyer;
    private JTable table;
    private CartTableModel tableModel;

    public ButtonEditor(Buyer buyer, JTable table, CartTableModel tableModel) {
        this.buyer = buyer;
        this.table = table;
        this.tableModel = tableModel;
        button = new JButton();
        button.addActionListener(this);
    }

    @Override
    public Object getCellEditorValue() {
        return label;
    }

    @Override
    public java.awt.Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        label = (value == null) ? "" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (isPushed) {
            int row = table.getSelectedRow();
            List<Product> products = new ArrayList<>(buyer.getCart().keySet());
            Product product = products.get(row);
            if (label.equals("del")) {
                buyer.removeProductFromCart(product);
            } else if (label.equals("↑")) {
                buyer.addProductToCart(product);
            } else if (label.equals("↓")) {
                buyer.decreaseProductQuantity(product);
            }
            tableModel.fireTableDataChanged();
            updateTotalPrice(); // Ensure the total price is updated
        }
        isPushed = false;
        fireEditingStopped();
    }

    private void updateTotalPrice() {
        // Notify the `MainFrame` to update the total price label
        if (table.getTopLevelAncestor() instanceof MainFrame) {
            ((MainFrame) table.getTopLevelAncestor()).updateTotalPriceLabel();
        }
    }
}
