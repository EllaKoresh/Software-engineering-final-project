
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.AbstractCellEditor;
import javax.swing.JButton;

import javax.swing.JTable;

import javax.swing.table.TableCellEditor;



class ButtonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
    private JButton button;
    private String label;
    private boolean isPushed;
    private Buyer buyer;
    private JTable table;

    public ButtonEditor(Buyer buyer, JTable table) {
        this.buyer = buyer;
        this.table = table;
        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(this);
    }

    @Override
    public java.awt.Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row,
            int column) {
        label = (value == null) ? "" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    @Override
    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            Product product = new ArrayList<>(buyer.getCart().keySet()).get(row);
            if (label.equals("Remove")) {
                buyer.removeProductFromCart(product);
            } else if (label.equals("Increase")) {
                buyer.increaseProductQuantity(product);
            }
            fireEditingStopped();
        }
        isPushed = false;
        return label;
    }


	@Override
    public void actionPerformed(ActionEvent e) {
        fireEditingStopped();
        table.repaint();
    }
}
