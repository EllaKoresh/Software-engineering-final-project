import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

public class CheckOutPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private JLabel lblTotalPrice;
    private JTextArea txtPurchaseDetails;
    private JButton btnPay;
    private JButton btnCancel;
    private JButton btnBackToMain;
    private MainFrame mainFrame;

    public CheckOutPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(null);

        lblTotalPrice = new JLabel("Total Price: $0.00");
        lblTotalPrice.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblTotalPrice.setBounds(10, 10, 200, 30);
        add(lblTotalPrice);

        txtPurchaseDetails = new JTextArea();
        txtPurchaseDetails.setEditable(false);
        txtPurchaseDetails.setBounds(10, 50, 430, 150);
        add(txtPurchaseDetails);

        btnPay = new JButton("Pay");
        btnPay.setBounds(330, 220, 100, 30);
        add(btnPay);

        btnCancel = new JButton("Cancel");
        btnCancel.setBounds(220, 220, 100, 30);
        add(btnCancel);

        btnBackToMain = new JButton("Back to Main");
        btnBackToMain.setBounds(10, 220, 150, 30);
        add(btnBackToMain);

        btnCancel.addActionListener(e -> {
            // Optionally add cancel logic here
            setVisible(false);
        });
        
        btnBackToMain.addActionListener(e -> {
            setVisible(false);
            mainFrame.showMainPanel(); // Show the main panel when "Back to Main" is pressed
        });
    }

    public void updateTotalPay(double totalPrice) {
        lblTotalPrice.setText(String.format("Total Price: $%.2f", totalPrice));
    }

    public void updatePurchaseDetails(Map<Product, Integer> cart) {
        StringBuilder details = new StringBuilder();
        for (Map.Entry<Product, Integer> entry : cart.entrySet()) {
            Product product = entry.getKey();
            int quantity = entry.getValue();
            details.append(String.format("%s x%d - $%.2f\n", product.getName(), quantity, product.getPrice()));
        }
        txtPurchaseDetails.setText(details.toString());
    }
}
