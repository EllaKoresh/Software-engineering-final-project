package application;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.HashMap;

public class Main extends Application {
    private HashMap<String, Product> productDatabase;
    private ObservableList<Product> items;
    private ObservableList<Product> cart;

    @Override
    public void start(Stage primaryStage) {
        // Initialize product database
        productDatabase = new HashMap<>();
        items = FXCollections.observableArrayList(
            new FruitAndVegetables(1.99, "FV001", "Apple"),
            new FruitAndVegetables(2.49, "FV002", "Banana"),
            new DryFood(3.99, "DF001", "Rice"),
            new DryFood(4.99, "DF002", "Pasta"),
            new HomeProduct(5.99, "HP001", "Detergent"),
            new HomeProduct(6.99, "HP002", "Dish Soap")
        );

        // Populate product database
        for (Product product : items) {
            productDatabase.put(product.getIdCode(), product);
        }

        cart = FXCollections.observableArrayList();

        showHomePage(primaryStage);
    }

    public void showHomePage(Stage primaryStage) {
        // Create home page buttons
        Button managerButton = new Button("Enter as Manager");
        managerButton.setOnAction(e -> openManagerView(primaryStage));
        Button buyerButton = new Button("Enter as Buyer");
        buyerButton.setOnAction(e -> openBuyerView(primaryStage));

        // Layout for home page
        VBox homeLayout = new VBox(managerButton, buyerButton);
        Scene homeScene = new Scene(homeLayout, 600, 400);

        primaryStage.setScene(homeScene);
        primaryStage.setTitle("Shopping Cart Home");
        primaryStage.show();
    }

    private void openManagerView(Stage stage) {
        ManagerView managerView = new ManagerView(productDatabase, items, this, stage);
        stage.setScene(managerView.getScene());
    }

    private void openBuyerView(Stage stage) {
        BuyerView buyerView = new BuyerView(productDatabase, items, cart, this, stage);
        stage.setScene(buyerView.getScene());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
