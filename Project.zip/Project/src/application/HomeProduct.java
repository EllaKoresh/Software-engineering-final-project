package application;

public class HomeProduct extends Product {
    public HomeProduct(double price, String idCode, String name) {
        super(price, idCode, name);
    }
}