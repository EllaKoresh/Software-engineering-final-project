package application;

public class FruitAndVegetables extends Product {
    public FruitAndVegetables(double price, String idCode, String name) {
        super(price, idCode, name);
    }
}