package application;

public abstract class Product {
    private double price;
    private String idCode;
    private String name;

    public Product(double price, String idCode, String name) {
        this.price = price;
        this.idCode = idCode;
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getIdCode() {
        return idCode;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name + " (ID: " + idCode + ", Price: $" + price + ")";
    }
}
