package application;

import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.HashMap;

public class BuyerView {
    private Scene scene;
    private HashMap<String, Product> productDatabase;
    private ObservableList<Product> items;
    private ObservableList<Product> cart;
    private TextArea cartContentArea;
    private Main mainApp;
    private Stage primaryStage;

    public BuyerView(HashMap<String, Product> productDatabase, ObservableList<Product> items, ObservableList<Product> cart, Main mainApp, Stage primaryStage) {
        this.productDatabase = productDatabase;
        this.items = items;
        this.cart = cart;
        this.mainApp = mainApp;
        this.primaryStage = primaryStage;

        ListView<Product> itemsListView = new ListView<>(items);
        ListView<Product> cartListView = new ListView<>(cart);

        Button addButton = new Button("Add to Cart");
        addButton.setOnAction(e -> addToCart(itemsListView.getSelectionModel().getSelectedItem()));
        Button removeButton = new Button("Remove from Cart");
        removeButton.setOnAction(e -> removeFromCart(cartListView.getSelectionModel().getSelectedItem()));
        Button payButton = new Button("Pay");
        payButton.setOnAction(e -> showPurchaseSummary());

        cartContentArea = new TextArea();
        cartContentArea.setEditable(false);
        updateCartContentArea();

        Button backButton = new Button("Back to Home");
        backButton.setOnAction(e -> mainApp.showHomePage(primaryStage));

        VBox layout = new VBox(itemsListView, addButton, cartListView, removeButton, payButton, cartContentArea, backButton);
        scene = new Scene(layout, 600, 400);
    }

    private void addToCart(Product selectedItem) {
        if (selectedItem != null && !cart.contains(selectedItem)) {
            cart.add(selectedItem);
            updateCartContentArea();
        }
    }

    private void removeFromCart(Product selectedItem) {
        if (selectedItem != null) {
            cart.remove(selectedItem);
            updateCartContentArea();
        }
    }

    private void updateCartContentArea() {
        StringBuilder content = new StringBuilder("Cart Contents:\n");
        for (Product item : cart) {
            content.append(item).append("\n");
        }
        cartContentArea.setText(content.toString());
    }

    private void showPurchaseSummary() {
        StringBuilder summary = new StringBuilder("Purchase Summary:\n");
        for (Product item : cart) {
            summary.append(item).append("\n");
        }
        summary.append("\nTotal: $").append(cart.stream().mapToDouble(Product::getPrice).sum());

        TextArea summaryArea = new TextArea(summary.toString());
        summaryArea.setEditable(false);

        Button creditCardButton = new Button("Pay with Credit Card");
        creditCardButton.setOnAction(e -> completePurchase());
        Button paypalButton = new Button("Pay with PayPal");
        paypalButton.setOnAction(e -> completePurchase());
        Button backButton = new Button("Back to Cart");
        backButton.setOnAction(e -> primaryStage.setScene(scene));

        VBox layout = new VBox(summaryArea, creditCardButton, paypalButton, backButton);
        Scene purchaseSummaryScene = new Scene(layout, 600, 400);
        primaryStage.setScene(purchaseSummaryScene);
    }

    private void completePurchase() {
        cart.clear();
        updateCartContentArea();

        TextArea thankYouArea = new TextArea("Thank you for your purchase!");
        thankYouArea.setEditable(false);

        Button backButton = new Button("Back to Home");
        backButton.setOnAction(e -> mainApp.showHomePage(primaryStage));

        VBox layout = new VBox(thankYouArea, backButton);
        Scene thankYouScene = new Scene(layout, 600, 400);
        primaryStage.setScene(thankYouScene);
    }

    public Scene getScene() {
        return scene;
    }
}
