package application;

import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.HashMap;

public class ManagerView {
    private Scene scene;
    private HashMap<String, Product> productDatabase;
    private ObservableList<Product> items;
    private ListView<Product> productListView;
    private Main mainApp;
    private Stage primaryStage;

    public ManagerView(HashMap<String, Product> productDatabase, ObservableList<Product> items, Main mainApp, Stage primaryStage) {
        this.productDatabase = productDatabase;
        this.items = items;
        this.mainApp = mainApp;
        this.primaryStage = primaryStage;

        TextField nameField = new TextField();
        nameField.setPromptText("Product Name");
        TextField idField = new TextField();
        idField.setPromptText("Product ID");
        TextField priceField = new TextField();
        priceField.setPromptText("Product Price");

        Button addButton = new Button("Add Product");
        addButton.setOnAction(e -> addProduct(nameField.getText(), idField.getText(), Double.parseDouble(priceField.getText())));

        Button updateButton = new Button("Update Product Price");
        updateButton.setOnAction(e -> updateProductPrice(idField.getText(), Double.parseDouble(priceField.getText())));

        productListView = new ListView<>(items);

        Button deleteButton = new Button("Delete Selected Product");
        deleteButton.setOnAction(e -> deleteProduct(productListView.getSelectionModel().getSelectedItem()));

        Button backButton = new Button("Back to Home");
        backButton.setOnAction(e -> mainApp.showHomePage(primaryStage));

        VBox layout = new VBox(nameField, idField, priceField, addButton, updateButton, productListView, deleteButton, backButton);
        scene = new Scene(layout, 600, 400);
    }

    private void addProduct(String name, String id, double price) {
        Product newProduct;
        if (id.startsWith("FV")) {
            newProduct = new FruitAndVegetables(price, id, name);
        } else if (id.startsWith("DF")) {
            newProduct = new DryFood(price, id, name);
        } else if (id.startsWith("HP")) {
            newProduct = new HomeProduct(price, id, name);
        } else {
            throw new IllegalArgumentException("Unknown product category");
        }

        productDatabase.put(id, newProduct);
        items.add(newProduct);
    }

    private void updateProductPrice(String id, double price) {
        Product product = productDatabase.get(id);
        if (product != null) {
            product.setPrice(price);
            productListView.refresh();
        }
    }

    private void deleteProduct(Product product) {
        if (product != null) {
            items.remove(product);
            productDatabase.remove(product.getIdCode());
        }
    }

    public Scene getScene() {
        return scene;
    }
}
