package application;

public interface Price {
    double getPrice();
}
