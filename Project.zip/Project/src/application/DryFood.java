package application;

public class DryFood extends Product {
    public DryFood(double price, String idCode, String name) {
        super(price, idCode, name);
    }
}